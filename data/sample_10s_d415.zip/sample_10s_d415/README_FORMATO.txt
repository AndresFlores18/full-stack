Paquete de muestra 10s - Intel RealSense D415 (sturdy-couscous)
Frames grabados: 22 en 12.28s

Archivos:
- latest_expo_payload.json : Ultimo frame completo (contrato JSON + 3 imagenes base64)
- frames.jsonl             : Todos los frames en secuencia (1 JSON por linea)
- images/                  : Imagenes JPG sueltas (rgb, depth, route_map) por frame
- final_map_state.npz      : Matrices NumPy finales (occupancy_grid, cost_grid, height_map_m, slope_map_deg)

Uso en Expo Go (iPad A16):
  <Image source={{ uri: payload.images.rgb }} />
  <Image source={{ uri: payload.images.depth }} />
  <Image source={{ uri: payload.images.route_map }} />
